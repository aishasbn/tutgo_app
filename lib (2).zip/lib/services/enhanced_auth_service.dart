import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class EnhancedAuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Get current user
  User? get currentUser => _auth.currentUser;

  // Auth state stream
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Register with email and password (untuk user biasa)
  Future<User?> registerWithEmailPasswordSafe(
    String name,
    String email,
    String password,
  ) async {
    try {
      print('🔄 Starting user registration for: $email');
      
      // Validate input
      if (name.trim().isEmpty || email.trim().isEmpty || password.isEmpty) {
        throw Exception('Semua field harus diisi');
      }
      
      if (password.length < 6) {
        throw Exception('Password minimal 6 karakter');
      }

      if (!_isValidEmail(email)) {
        throw Exception('Format email tidak valid');
      }

      // Check if email already exists
      final existingUser = await _checkEmailExists(email);
      if (existingUser) {
        throw Exception('Email sudah digunakan. Silakan gunakan email lain.');
      }

      // Create user account
      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      
      User? user = result.user;
      if (user == null) {
        throw Exception('Gagal membuat akun');
      }

      // Create user document in Firestore
      await _createUserDocument(user.uid, {
        'uid': user.uid,
        'name': name.trim(),
        'email': email.trim(),
        'userType': 'user',
        'role': 'passenger',
        'isActive': true,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      // Update display name
      await user.updateDisplayName(name.trim());

      print('✅ User registration successful');
      return user;
    } on FirebaseAuthException catch (e) {
      print('❌ Firebase Auth error during registration: ${e.code}');
      throw Exception(_handleAuthError(e));
    } catch (e) {
      print('❌ General error during registration: $e');
      rethrow;
    }
  }

  // Sign in with email and password (untuk user biasa)
  Future<User?> signInWithEmailPassword(String email, String password) async {
    try {
      print('🔄 Starting user login for: $email');
      
      // Validate input
      if (email.trim().isEmpty || password.isEmpty) {
        throw Exception('Email dan password harus diisi');
      }

      // Sign in
      UserCredential result = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      
      User? user = result.user;
      if (user == null) {
        throw Exception('Login gagal');
      }

      // Ensure user document exists and is a user (not staff)
      final userData = await _getUserData(user.uid);
      if (userData == null) {
        await _createUserDocument(user.uid, {
          'uid': user.uid,
          'name': user.displayName ?? 'User',
          'email': user.email,
          'userType': 'user',
          'role': 'passenger',
          'isActive': true,
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        });
      } else if (userData['userType'] == 'staff') {
        await _auth.signOut();
        throw Exception('Akun ini adalah akun staff. Silakan login melalui Staff Login.');
      }

      print('✅ User login successful');
      return user;
    } on FirebaseAuthException catch (e) {
      print('❌ Firebase Auth error during user login: ${e.code}');
      throw Exception(_handleAuthError(e));
    } catch (e) {
      print('❌ General error during user login: $e');
      rethrow;
    }
  }

  // Sign in staff with ID (untuk staff)
  Future<User?> signInStaffWithId(String staffId, String password) async {
    try {
      print('🔄 Starting staff login for: $staffId');
      
      // Validate input
      if (staffId.trim().isEmpty || password.isEmpty) {
        throw Exception('Staff ID dan password harus diisi');
      }

      // Find staff by staffId
      final staffQuery = await _firestore
          .collection('users')
          .where('staffId', isEqualTo: staffId.trim().toUpperCase())
          .where('userType', isEqualTo: 'staff')
          .limit(1)
          .get();

      if (staffQuery.docs.isEmpty) {
        throw Exception('Staff ID tidak ditemukan. Hubungi administrator.');
      }

      final staffData = staffQuery.docs.first.data();
      final email = staffData['email'];
      final isActive = staffData['isActive'] ?? true;

      // Check if staff account is active
      if (!isActive) {
        throw Exception('Akun staff tidak aktif. Hubungi administrator.');
      }

      // Sign in with email
      UserCredential result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      User? user = result.user;
      if (user == null) {
        throw Exception('Login staff gagal');
      }

      print('✅ Staff login successful');
      return user;
    } on FirebaseAuthException catch (e) {
      print('❌ Firebase Auth error during staff login: ${e.code}');
      throw Exception(_handleAuthError(e));
    } catch (e) {
      print('❌ General error during staff login: $e');
      rethrow;
    }
  }

  // Sign out
  Future<void> signOut() async {
    try {
      await _auth.signOut();
      print('✅ User signed out successfully');
    } catch (e) {
      print('❌ Sign out error: $e');
      throw Exception('Gagal logout: $e');
    }
  }

  // Reset password
  Future<void> resetPassword(String email) async {
    try {
      if (email.trim().isEmpty) {
        throw Exception('Email harus diisi');
      }

      await _auth.sendPasswordResetEmail(email: email.trim());
      print('✅ Password reset email sent');
    } on FirebaseAuthException catch (e) {
      throw Exception(_handleAuthError(e));
    } catch (e) {
      rethrow;
    }
  }

  // Check if user is staff
  Future<bool> isStaff() async {
    try {
      final user = currentUser;
      if (user == null) return false;

      final userData = await _getUserData(user.uid);
      return userData?['userType'] == 'staff';
    } catch (e) {
      print('❌ Error checking staff status: $e');
      return false;
    }
  }

  // Get user data
  Future<Map<String, dynamic>?> getUserData() async {
    try {
      final user = currentUser;
      if (user == null) return null;

      final userData = await _getUserData(user.uid);
      
      // Pastikan data yang dikembalikan adalah Map<String, dynamic>
      if (userData != null && userData is Map<String, dynamic>) {
        return userData;
      } else {
        print('⚠️ User data format is not as expected: $userData');
        return {};
      }
    } catch (e) {
      print('❌ Error getting user data: $e');
      return null;
    }
  }

  // Update user profile
  Future<void> updateUserProfile({
    String? name,
    Map<String, dynamic>? additionalData,
  }) async {
    try {
      final user = currentUser;
      if (user == null) throw Exception('User tidak ditemukan');

      // Update display name if provided
      if (name != null && name.trim().isNotEmpty) {
        await user.updateDisplayName(name.trim());
      }

      // Update Firestore document
      Map<String, dynamic> updateData = {
        'updatedAt': FieldValue.serverTimestamp(),
      };

      if (name != null && name.trim().isNotEmpty) {
        updateData['name'] = name.trim();
      }

      if (additionalData != null) {
        updateData.addAll(additionalData);
      }

      await _firestore.collection('users').doc(user.uid).update(updateData);
      print('✅ User profile updated successfully');
    } catch (e) {
      print('❌ Error updating user profile: $e');
      rethrow;
    }
  }

  // Check Firebase connection
  Future<bool> checkFirebaseConnection() async {
    try {
      // Try to read from Firestore to check connection
      await _firestore.collection('connection_test').limit(1).get();
      return true;
    } catch (e) {
      print('❌ Firebase connection check failed: $e');
      return false;
    }
  }

  // Get detailed error info
  String getDetailedErrorInfo(dynamic e) {
    if (e is FirebaseAuthException) {
      return 'Firebase Auth Error: ${e.code} - ${e.message}';
    } else if (e is FirebaseException) {
      return 'Firebase Error: ${e.code} - ${e.message}';
    } else {
      return 'Error: $e';
    }
  }

  // Private helper methods
  Future<Map<String, dynamic>?> _getUserData(String uid) async {
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      
      if (doc.exists) {
        final data = doc.data();
        if (data != null && data is Map<String, dynamic>) {
          return data;
        } else {
          print('⚠️ Firestore document data is not Map<String, dynamic>: $data');
          return {};
        }
      }
      return null;
    } catch (e) {
      print('❌ Error getting user data from Firestore: $e');
      return null;
    }
  }

  Future<void> _createUserDocument(String uid, Map<String, dynamic> data) async {
    const maxRetries = 3;
    
    for (int attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        await _firestore.collection('users').doc(uid).set(data);
        
        // Verify document was created
        final doc = await _firestore.collection('users').doc(uid).get();
        if (doc.exists) {
          print('✅ User document created successfully');
          return;
        }
      } catch (e) {
        print('⚠️ Attempt $attempt failed to create document: $e');
        if (attempt == maxRetries) {
          throw Exception('Gagal menyimpan data user');
        }
        await Future.delayed(Duration(milliseconds: 500 * attempt));
      }
    }
  }

  Future<bool> _checkEmailExists(String email) async {
    try {
      final query = await _firestore
          .collection('users')
          .where('email', isEqualTo: email.trim())
          .limit(1)
          .get();
      return query.docs.isNotEmpty;
    } catch (e) {
      return false;
    }
  }

  bool _isValidEmail(String email) {
    return RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }

  String _handleAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'weak-password':
        return 'Password terlalu lemah. Gunakan kombinasi huruf, angka, dan simbol.';
      case 'email-already-in-use':
        return 'Email sudah digunakan oleh akun lain.';
      case 'invalid-email':
        return 'Format email tidak valid.';
      case 'user-not-found':
        return 'Akun tidak ditemukan. Periksa email Anda.';
      case 'wrong-password':
        return 'Password salah. Silakan coba lagi.';
      case 'user-disabled':
        return 'Akun telah dinonaktifkan. Hubungi administrator.';
      case 'too-many-requests':
        return 'Terlalu banyak percobaan. Coba lagi dalam beberapa menit.';
      case 'invalid-credential':
        return 'Email atau password salah.';
      case 'network-request-failed':
        return 'Koneksi internet bermasalah. Periksa koneksi Anda.';
      default:
        return e.message ?? 'Terjadi kesalahan yang tidak diketahui.';
    }
  }
}
