package com.example.tutgo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
